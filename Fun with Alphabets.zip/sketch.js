var a,aIMG,b,bIMG,c,cIMG,d,dIMG,e,eIMG,f,fIMG,
g,gIMG,h,hIMG,i,iIMG,j,jIMG,k,kIMG,l,lIMG,
m,mIMG,n,nIMG,o,oIMG,p,pIMG,q,qIMG,r,rIMG,
s,sIMG,t,tIMG,u,uIMG,v,vIMG,w,wIMG,x,xIMG,
y,yIMG,z,zIMG,backgroundImg,backImg,baImg,background1,background2,background3;

var apple,appleIMG,banana,bananaIMG,carrot,carrotIMG,dog,dogIMG,eagle,eagleIMG,fish,fishIMG,
gorrila,gorrilaIMG,hen,henIMG,icecream,icecreamIMG,jug,jugIMG,kite,kiteIMG,lemon,lemonIMG
,monkey,monkeyIMG,nest,nestIMG,ostrich,ostrichIMG,pig,pigIMG,question,questionIMG,rabbit
,rabbitIMG,snake,snakeIMG,tree,treeIMG,umbrella,umbrellaIMG,vase,vaseIMG,watch,watchIMG,
xylo,xyloIMg,yarn,yarnIMG,zebra,zebraIMG,tr,trImg;

var score;

var start , startIMG

function preload(){

  pointsound = loadSound("points.mp3");
  backsound = loadSound("background.mp3");
  aIMG = loadImage("a i.png");
  bIMG = loadImage("b.png");
  cIMG = loadImage("c.png");
  dIMG = loadImage("d.png");
  eIMG = loadImage("e.png");
  fIMG = loadImage("f.png");
  gIMG = loadImage("g.png");
  hIMG = loadImage("h.png");
  iIMG = loadImage("i.png");
  jIMG = loadImage("j.png");
  kIMG = loadImage("k.png");
  lIMG = loadImage("l.png");
  mIMG = loadImage("m.png");
  nIMG = loadImage("n.png");
  oIMG = loadImage("o.png");
  pIMG = loadImage("p.png");
  qIMG = loadImage("q.png");
  rIMG = loadImage("r.png");
  sIMG = loadImage("s.png");
  tIMG = loadImage("t.png");
  uIMG = loadImage("u.png");
  vIMG = loadImage("v.png");
  wIMG = loadImage("w.png");
  xIMG = loadImage("x.png");
  yIMG = loadImage("y.png");
  zIMG = loadImage("z.png");
  backgroundImg = loadImage("back.jfif")
backImg = loadImage("abc.png")
baImg = loadImage("white.png")
trImg = loadImage("tr.png")

  appleIMG = loadImage("apple.png")
  bananaIMG = loadImage("banana.png")
  carrotIMG = loadImage("carrot.png")
  dogIMG = loadImage("dog.png")
  eagleIMG = loadImage("eagle.png")
  fishIMG = loadImage("fish.png")
  gorrilaIMG = loadImage("gorrila.png")
  henIMG = loadImage("hen.png")
icecreamIMG = loadImage("icecream.png")
jugIMG = loadImage("jug.png")
kiteIMG = loadImage("kite.png")
lemonIMG = loadImage("lemon.png")
monkeyIMG = loadImage("monkey.png")
nestIMG = loadImage("nest.png")
ostrichIMG = loadImage("ostrich.png")
pigIMG = loadImage("pig.png")
questionIMG = loadImage("question.png")
rabbitIMG = loadImage("rabbit.png")
snakeIMG = loadImage("snake.png")
treeIMG = loadImage("tree.png")
umbrellaIMG = loadImage("umbrella.png")
vaseIMG = loadImage("vase.png")
watchIMG = loadImage("watch.png")
xyloIMg = loadImage("xylophon.png")
yarnIMG = loadImage("yarn.png")
zebraIMG = loadImage("zebra.png")

startIMG = loadImage("play.png")
}

function setup(){
 createCanvas(1536,790)
backsound.loop();

 aB = new Group();
bB = new Group();
cB = new Group();
dB = new Group();
eB = new Group();
fB = new Group();
gB = new Group();
hB = new Group();
iB = new Group();
jB = new Group();
kB = new Group();
lB = new Group();
mB = new Group();
nB = new Group();
oB = new Group();
pB = new Group();
qB = new Group();
rB = new Group();
sB = new Group();
tB = new Group();
uB = new Group();
vB = new Group();
wB = new Group();
xB = new Group();
yB = new Group();
zB = new Group();

aA = new Group();
bA = new Group();
cA = new Group();
dA = new Group();
eA = new Group();
fA = new Group();
gA = new Group();
hA = new Group();
iA = new Group();
jA = new Group();
kA = new Group();
lA = new Group();
mA = new Group();
nA = new Group();
oA = new Group();
pA = new Group();
qA = new Group();
rA = new Group();
sA = new Group();
tA = new Group();
uA = new Group();
vA = new Group();
wA = new Group();
xA = new Group();
yA = new Group();
zA = new Group();


ahillum();
bhillum();
chillum();
dhillum();
ehillum();
fhillum();
ghillum();
hhillum();
ihillum();
jhillum();
khillum();
lhillum();
mhillum();
nhillum();
ohillum();
phillum();
qhillum();
rhillum();
shillum();
thillum();
uhillum();
vhillum();
whillum();
xhillum();
yhillum();
zhillum();

appleA();
bananaA();
carrotA();
dogA();
eagleA();
fishA();
gorrilaA();
henA();
icecreamA();
jugA();
kiteA();
lemonA();
monkeyA();
nestA();
ostrichA();
pigA();
questionA();
rabbitA();
snakeA();
treeA();
umbrellaA();
vaseA();
watchA();
xylophoneA();
yarnA();
zebraA();
backgroundC();
backgroundA();
backgroundB();

score = 0


start = createSprite(768,630,10,10)
start.scale = 0.9
start.addImage(startIMG)

tr = createSprite(768,375,10,10)
tr.scale = 0.9
tr.addImage(trImg)
tr.visible = false
}


function draw(){
 
  background(255)


var select_hillum = Math.round(random(1,52));
  
if (World.frameCount % 100 == 0) {
  if (select_hillum == 1) {
   ahillum();
  } else if (select_hillum == 2) {
    bhillum();
  } else if (select_hillum ==3) {
    chillum();
  } else if (select_hillum == 4) {
    dhillum();
  } else if (select_hillum == 5) {
    ehillum();
  } else if (select_hillum == 6) {
    fhillum();
  } else if (select_hillum == 7) {
    ghillum();
  } else if (select_hillum == 8) {
    hhillum();
  } else if (select_hillum == 9) {
    ihillum();
  } else if (select_hillum == 10) {
    jhillum();
  } else if (select_hillum == 11) {
    khillum();
  } else if (select_hillum == 12) {
    lhillum();
  } else if (select_hillum == 13) {
    mhillum();
  } else if (select_hillum == 14) {
    nhillum();
  } else if (select_hillum == 15) {
    ohillum();
  } else if (select_hillum == 16) {
    phillum();
  } else if (select_hillum == 17) {
    qhillum();
  } else if (select_hillum == 18) {
    rhillum();
  } else if (select_hillum == 19) {
    shillum();
  } else if (select_hillum == 20) {
    thillum();
  } else if (select_hillum == 21) {
    uhillum();
  } else if (select_hillum == 22) {
    vhillum();
  } else if (select_hillum == 23) {
    whillum();
  } else if (select_hillum == 24) {
    xhillum();
  } else if (select_hillum == 25) {
    yhillum();
  } else if (select_hillum == 26) {
    zhillum();
  } else if (select_hillum == 27) {
    appleA();
  } else if (select_hillum == 28) {
    bananaA();
  } else if (select_hillum == 29) {
    carrotA();
  } else if (select_hillum == 30) {
    dogA();
  } else if (select_hillum == 31) {
    eagleA();
  } else if (select_hillum == 32) {
    fishA();
  } else if (select_hillum == 33) {
    gorrilaA();
  } else if (select_hillum == 34) {
    henA();
  } else if (select_hillum == 35) {
    icecreamA();
  } else if (select_hillum == 36) {
    jugA();
  } else if (select_hillum == 37) {
    kiteA();
  } else if (select_hillum == 38) {
    lemonA();
  } else if (select_hillum == 39) {
    monkeyA();
  } else if (select_hillum == 40) {
    nestA();
  } else if (select_hillum == 41) {
    ostrichA();
  } else if (select_hillum == 42) {
    pigA();
  } else if (select_hillum == 43) {
    questionA();
  } else if (select_hillum == 44) {
    rabbitA();
  } else if (select_hillum == 45) {
    snakeA();
  } else if (select_hillum == 46) {
    treeA();
  } else if (select_hillum == 47) {
    umbrellaA();
  } else if (select_hillum == 48) {
    vaseA();
  } else if (select_hillum == 49) {
    watchA();
  } else if (select_hillum == 50) {
   xylophoneA();
  } else if (select_hillum == 51) {
    yarnA();
  } else {
    zebraA();
  }
}

  
if(keyDown("a")){
aB.destroyEach();
aA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("b")){
bB.destroyEach();
bA.destroyEach();
pointsound.play();
score = score+1
}

if(keyDown("c")){
cB.destroyEach();
cA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("d")){
dB.destroyEach();
dA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("e")){
eB.destroyEach();
eA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("f")){
fB.destroyEach();
fA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("g")){
gB.destroyEach();
gA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("h")){
hB.destroyEach();
hA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("i")){
iB.destroyEach();
iA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("j")){
jB.destroyEach();
jA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("k")){
kB.destroyEach();
kA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("l")){
lB.destroyEach();
lA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("m")){
mB.destroyEach();
mA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("n")){
nB.destroyEach();
nA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("o")){
oB.destroyEach();
oA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("p")){
pB.destroyEach();
pA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("q")){
qB.destroyEach();
qA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("r")){
rB.destroyEach();
rA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("s")){
sB.destroyEach();
sA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("t")){
tB.destroyEach();
tA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("u")){
uB.destroyEach();
uA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("v")){
vB.destroyEach();
vA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("w")){
wB.destroyEach();
wA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("x")){
xB.destroyEach();
xA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("y")){
yB.destroyEach();
yA.destroyEach();
pointsound.play();
score = score+1
}
  
if(keyDown("z")){
zB.destroyEach();
zA.destroyEach();
pointsound.play();
score = score+1
}
if(score>49){
  start.visible = true
  background2.visible = true
  background1.visible = false
  score = 0

tr.visible = true

  aB.destroyEach()
  bB.destroyEach()
  cB.destroyEach()
  dB.destroyEach()
  eB.destroyEach()
  fB.destroyEach()
  gB.destroyEach()
  hB.destroyEach()
  iB.destroyEach()
  jB.destroyEach()
  kB.destroyEach()
  lB.destroyEach()
  mB.destroyEach()
  nB.destroyEach()
  oB.destroyEach()
  pB.destroyEach()
  qB.destroyEach()
  rB.destroyEach()
  sB.destroyEach()
  tB.destroyEach()
  uB.destroyEach()
  vB.destroyEach()
  wB.destroyEach()
  xB.destroyEach()
  yB.destroyEach()
  zB.destroyEach()

  aA.destroyEach();
  bA.destroyEach();
  cA.destroyEach();
  dA.destroyEach();
  eA.destroyEach();
  fA.destroyEach();
  gA.destroyEach();
  hA.destroyEach();
  iA.destroyEach();
  jA.destroyEach();
  kA.destroyEach();
  lA.destroyEach();
  mA.destroyEach();
  nA.destroyEach();
  oA.destroyEach();
  pA.destroyEach();
  qA.destroyEach();
  rA.destroyEach();
  sA.destroyEach();
  tA.destroyEach();
  uA.destroyEach();
  vA.destroyEach();
  wA.destroyEach();
  xA.destroyEach();
  yA.destroyEach();
  zA.destroyEach();
}

if(mousePressedOver(start)) {

  background1.visible = true
  background2.visible = false
  start.visible = false;
  tr.visible = false
  aB.destroyEach()
  bB.destroyEach()
  cB.destroyEach()
  dB.destroyEach()
  eB.destroyEach()
  fB.destroyEach()
  gB.destroyEach()
  hB.destroyEach()
  iB.destroyEach()
  jB.destroyEach()
  kB.destroyEach()
  lB.destroyEach()
  mB.destroyEach()
  nB.destroyEach()
  oB.destroyEach()
  pB.destroyEach()
  qB.destroyEach()
  rB.destroyEach()
  sB.destroyEach()
  tB.destroyEach()
  uB.destroyEach()
  vB.destroyEach()
  wB.destroyEach()
  xB.destroyEach()
  yB.destroyEach()
  zB.destroyEach()

  aA.destroyEach();
  bA.destroyEach();
  cA.destroyEach();
  dA.destroyEach();
  eA.destroyEach();
  fA.destroyEach();
  gA.destroyEach();
  hA.destroyEach();
  iA.destroyEach();
  jA.destroyEach();
  kA.destroyEach();
  lA.destroyEach();
  mA.destroyEach();
  nA.destroyEach();
  oA.destroyEach();
  pA.destroyEach();
  qA.destroyEach();
  rA.destroyEach();
  sA.destroyEach();
  tA.destroyEach();
  uA.destroyEach();
  vA.destroyEach();
  wA.destroyEach();
  xA.destroyEach();
  yA.destroyEach();
  zA.destroyEach();
}

    drawSprites();
    fill(0)
    textSize(30)
    text("Score: "+ score, 1336,50);
  
}



function backgroundA(){
  background1= createSprite(720,350,100,550)
  background1.addImage(backgroundImg)
  background1.scale = 5.5
  background1.visible = false
}

function backgroundB(){
  background2= createSprite(720,350,100,550)
  background2.addImage(backImg)
  background2.scale = 4
  background2.visible = true
}
function backgroundC(){
  background3= createSprite(720,350,100,550)
  background3.addImage(baImg)
  background3.scale = 10
  background3.visible = true
}

function ahillum() {
  var a = createSprite(0,Math.round(random(10, 550)), 10, 10);
  a.addImage(aIMG);
a.velocityX =5;
  a.lifetime = 350;
  a.scale = 0.6;
  aB.add(a)
}

function bhillum() {
  var b = createSprite(0,Math.round(random(10, 550)), 10, 10);
  b.addImage(bIMG);
  b.velocityX =7;
  b.lifetime = 350;
  b.scale = 0.6;
  bB.add(b)
}

function chillum() {
  var c = createSprite(0,Math.round(random(10, 550)), 10, 10);
  c.addImage(cIMG);
  c.velocityX =9;
  c.lifetime = 350;
  c.scale = 0.6;
  cB.add(c)
}

function dhillum() {
  var d = createSprite(0,Math.round(random(10, 550)), 10, 10);
  d.addImage(dIMG);
  d.velocityX =11;
  d.lifetime = 350;
  d.scale = 0.6;
  dB.add(d)
}

function ehillum() {
  var e = createSprite(0,Math.round(random(10, 550)), 10, 10);
  e.addImage(eIMG);
 e.velocityX =5;
  e.lifetime = 350;
  e.scale = 0.6;
  eB.add(e)
}

function fhillum() {
  var f = createSprite(0,Math.round(random(10, 550)), 10, 10);
  f.addImage(fIMG);
 f.velocityX =7;
  f.lifetime = 350;
  f.scale = 0.6;
  fB.add(f)
}

function ghillum() {
  var g = createSprite(0,Math.round(random(10, 550)), 10, 10);
  g.addImage(gIMG);
  g.velocityX =9;
  g.lifetime = 350;
  g.scale = 0.6;
  gB.add(g)
}

function hhillum() {
  var h = createSprite(0,Math.round(random(10, 550)), 10, 10);
  h.addImage(hIMG);
  h.velocityX =11;
  h.lifetime = 350;
  h.scale = 0.6;
  hB.add(h)
}

function ihillum() {
  var i = createSprite(0,Math.round(random(10, 550)), 10, 10);
  i.addImage(iIMG);
  i.velocityX =5;
  i.lifetime = 350;
  i.scale = 0.6;
  iB.add(i)
}

function jhillum() {
  var j = createSprite(0,Math.round(random(10, 550)), 10, 10);
  j.addImage(jIMG);
  j.velocityX =7;
  j.lifetime = 350;
  j.scale = 0.6;
  jB.add(j)
}

function khillum() {
  var k = createSprite(0,Math.round(random(10, 550)), 10, 10);
  k.addImage(kIMG);
  k.velocityX =9;
  k.lifetime = 350;
  k.scale = 0.6;
  kB.add(k)
}

function lhillum() {
  var l = createSprite(0,Math.round(random(10, 550)), 10, 10);
  l.addImage(lIMG);
 l.velocityX =11;
  l.lifetime = 350;
  l.scale = 0.6;
  lB.add(l)
}

function mhillum() {
  var m = createSprite(0,Math.round(random(10, 550)), 10, 10);
  m.addImage(mIMG);
  m.velocityX =5;
  m.lifetime = 350 ;
  m.scale = 0.6;
  mB.add(m)
}

function nhillum() {
  var n = createSprite(0,Math.round(random(10, 550)), 10, 10);
  n.addImage(nIMG);
  n.velocityX =7;
  n.scale = 0.4
  n.lifetime = 350;
 nB.add(n)
}

 function ohillum() {
  var o = createSprite(0,Math.round(random(10, 550)), 10, 10);
  o.addImage(oIMG);
  o.velocityX =9;
  o.scale = 0.6
  o.lifetime = 350;
 oB.add(o)
 }

 function phillum() {
  var p = createSprite(0,Math.round(random(10, 550)), 10, 10);
  p.addImage(pIMG);
  p.velocityX =11;
  p.scale = 0.6
  p.lifetime = 350;
 pB.add(p)
 }

 function qhillum() {
  var q = createSprite(0,Math.round(random(10, 550)), 10, 10);
  q.addImage(qIMG);
  q.velocityX =5;
  q.scale = 0.6
  q.lifetime = 350;
 qB.add(q)
 }

 function rhillum() {
  var r = createSprite(0,Math.round(random(10, 550)), 10, 10);
  r.addImage(rIMG);
  r.velocityX =7;
  r.scale = 0.6
  r.lifetime = 350;
 rB.add(r)
 }

 function shillum() {
  var s = createSprite(0,Math.round(random(10, 550)), 10, 10);
  s.addImage(sIMG);
  s.velocityX =9;
  s.scale = 0.6
  s.lifetime = 350;
 sB.add(s)
 }

 function thillum() {
  var t = createSprite(0,Math.round(random(10, 550)), 10, 10);
  t.addImage(tIMG);
  t.velocityX =11;
  t.scale = 0.6
  t.lifetime = 350;
 tB.add(t)
 }

 function uhillum() {
  var u = createSprite(0,Math.round(random(10, 550)), 10, 10);
  u.addImage(uIMG);
  u.velocityX =5;
  u.scale = 0.6
  u.lifetime = 350;
 uB.add(u)
 }

 function vhillum() {
  var v = createSprite(0,Math.round(random(10, 550)), 10, 10);
 v.addImage(vIMG);
 v.velocityX =7;
 v.scale = 0.6
 v.lifetime = 350;
 vB.add(v)
 }

 function whillum() {
  var w = createSprite(0,Math.round(random(10, 550)), 10, 10);
  w.addImage(wIMG);
  w.velocityX =5
  w.scale = 0.6
  w.lifetime = 350;
 wB.add(w)
 }

 function xhillum() {
  var x = createSprite(0,Math.round(random(10, 550)), 10, 10);
 x.addImage(xIMG);
  x.velocityX =9;
  x.scale = 0.6
  x.lifetime = 350;
 xB.add(x)
 }

 function yhillum() {
  var y = createSprite(0,Math.round(random(10, 550)), 10, 10);
 y.addImage(yIMG);
  y.velocityX =11;
  y.scale = 0.6
  y.lifetime = 350;
 yB.add(y)
 }

 function zhillum() {
  var z = createSprite(0,Math.round(random(10, 550)), 10, 10);
  z.addImage(zIMG);
  z.velocityX =5;
  z.scale = 0.6
  z.lifetime = 350;
 zB.add(z)
 }




 function appleA() {
  var apple = createSprite(0,Math.round(random(10, 550)), 10, 10);
  apple.addImage(appleIMG);
  apple.velocityX =7;
  apple.scale = 0.6
  apple.lifetime = 350;
 aA.add(apple)
 }

 function bananaA() {
  var banana = createSprite(0,Math.round(random(10, 550)), 10, 10);
  banana.addImage(bananaIMG);
 banana.velocityX =9;
  banana.scale = 0.6
  banana.lifetime = 350;
 bA.add(banana)
 }

 function carrotA() {
  var carrot = createSprite(0,Math.round(random(10, 550)), 10, 10);
  carrot.addImage(carrotIMG);
  carrot.velocityX =11;
  carrot.scale = 0.6
  carrot.lifetime = 350;
 cA.add(carrot)
 }
 
 function dogA() {
  var dog = createSprite(0,Math.round(random(10, 550)), 10, 10);
  dog.addImage(dogIMG);
  dog.velocityX =5;
  dog.scale = 0.6
  dog.lifetime = 350;
 dA.add(dog)
 }
   
 function eagleA() {
  var eagle = createSprite(0,Math.round(random(10, 550)), 10, 10);
  eagle.addImage(eagleIMG);
  eagle.velocityX =7;
  eagle.scale = 0.6
  eagle.lifetime = 350;
 eA.add(eagle)
 }
    
 function fishA() {
  var fish = createSprite(0,Math.round(random(10, 550)), 10, 10);
  fish.addImage(fishIMG);
  fish.velocityX =9;
  fish.scale = 0.6
  fish.lifetime = 350;
 fA.add(fish)
 }
    
 function gorrilaA() {
  var gorrila = createSprite(0,Math.round(random(10, 550)), 10, 10);
  gorrila.addImage(gorrilaIMG);
  gorrila.velocityX =11;
  gorrila.scale = 0.6
  gorrila.lifetime = 350;
 gA.add(gorrila)
 }
     
 function henA() {
  var hen = createSprite(0,Math.round(random(10, 550)), 10, 10);
  hen.addImage(henIMG);
  hen.velocityX =5;
  hen.scale = 0.6
  hen.lifetime = 350;
 hA.add(hen)
 }
     
 function icecreamA() {
  var icecream = createSprite(0,Math.round(random(10, 550)), 10, 10);
  icecream.addImage(icecreamIMG);
  icecream.velocityX =7;
  icecream.scale = 0.6
  icecream.lifetime = 350;
 iA.add(icecream)
 }
      
 function jugA() {
  var jug = createSprite(0,Math.round(random(10, 550)), 10, 10);
  jug.addImage(jugIMG);
  jug.velocityX =9;
  jug.scale = 0.6
  jug.lifetime = 350;
 jA.add(jug)
 }
      
 function kiteA() {
  var kite = createSprite(0,Math.round(random(10, 550)), 10, 10);
  kite.addImage(kiteIMG);
  kite.velocityX =11;
  kite.scale = 0.6
  kite.lifetime = 350;
 kA.add(kite)
 }
       
 function lemonA() {
  var lemon = createSprite(0,Math.round(random(10, 550)), 10, 10);
  lemon.addImage(lemonIMG);
  lemon.velocityX =5;
  lemon.scale = 0.6
  lemon.lifetime = 350;
 lA.add(lemon)
 }
       
 function monkeyA() {
  var monkey = createSprite(0,Math.round(random(10, 550)), 10, 10);
 monkey.addImage(monkeyIMG);
  monkey.velocityX =7;
 monkey.scale = 0.6
 monkey.lifetime = 350;
 mA.add(monkey)
 }
       
 function nestA() {
  var nest = createSprite(0,Math.round(random(10, 550)), 10, 10);
  nest.addImage(nestIMG);
 nest.velocityX =9;
  nest.scale = 0.6
  nest.lifetime = 350;
 nA.add(nest)
 }
       
 function ostrichA() {
  var ostrich = createSprite(0,Math.round(random(10, 550)), 10, 10);
  ostrich.addImage(ostrichIMG);
 ostrich.velocityX =11;
  ostrich.scale = 0.6
  ostrich.lifetime = 350;
 oA.add(ostrich)
 }
       
 function pigA() {
  var pig = createSprite(0,Math.round(random(10, 550)), 10, 10);
  pig.addImage(pigIMG);
  pig.velocityX =5;
  pig.scale = 0.6
  pig.lifetime = 350;
 pA.add(pig)
 }
       
 function questionA() {
  var question = createSprite(0,Math.round(random(10, 550)), 10, 10);
  question.addImage(questionIMG);
  question.velocityX =7;
  question.scale = 0.6
  question.lifetime = 350;
 qA.add(question)
 }
       
 function rabbitA() {
  var rabbit = createSprite(0,Math.round(random(10, 550)), 10, 10);
  rabbit.addImage(rabbitIMG);
  rabbit.velocityX =9;
  rabbit.scale = 0.6
  rabbit.lifetime = 350;
 rA.add(rabbit)
 }
       
 function snakeA() {
  var snake = createSprite(0,Math.round(random(10, 550)), 10, 10);
  snake.addImage(snakeIMG);
  snake.velocityX =11;
  snake.scale = 0.6
  snake.lifetime = 350;
 sA.add(snake)
 }
       
 function treeA() {
  var tree = createSprite(0,Math.round(random(10, 550)), 10, 10);
  tree.addImage(treeIMG);
  tree.velocityX =5;
  tree.scale = 0.6
  tree.lifetime = 350;
 tA.add(tree)
 }
       
 function umbrellaA() {
  var umbrella = createSprite(0,Math.round(random(10, 550)), 10, 10);
  umbrella.addImage(umbrellaIMG);
  umbrella.velocityX =7;
  umbrella.scale = 0.6
  umbrella.lifetime = 350;
 uA.add(umbrella)
 }
       
 function vaseA() {
  var vase = createSprite(0,Math.round(random(10, 550)), 10, 10);
  vase.addImage(vaseIMG);
  vase.velocityX =9;
  vase.scale = 0.6
  vase.lifetime = 350;
 vA.add(vase)
 }
       
 function watchA() {
  var watch = createSprite(0,Math.round(random(10, 550)), 10, 10);
  watch.addImage(watchIMG);
  watch.velocityX =7;
  watch.scale = 0.9
  watch.lifetime = 350;
 wA.add(watch)
 }
       
 function xylophoneA() {
  var xylo = createSprite(0,Math.round(random(10, 550)), 10, 10);
  xylo.addImage(xyloIMg);
  xylo.velocityX =9;
  xylo.scale = 0.6
  xylo.lifetime = 350;
 xA.add(xylo)
 }
       
 function yarnA() {
  var yarn = createSprite(0,Math.round(random(10, 550)), 10, 10);
  yarn.addImage(yarnIMG);
  yarn.velocityX =11;
  yarn.scale = 0.6
  yarn.lifetime = 350;
 yA.add(yarn)
 }
       
 function zebraA() {
  var zebra = createSprite(0,Math.round(random(10, 550)), 10, 10);
  zebra.addImage(zebraIMG);
  zebra.velocityX =5;
  zebra.scale = 0.6
  zebra.lifetime = 350;
  zA.add(zebra)
 }

